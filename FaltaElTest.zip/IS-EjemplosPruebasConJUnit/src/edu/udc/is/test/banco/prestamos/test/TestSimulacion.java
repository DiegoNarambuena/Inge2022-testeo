package edu.udc.is.test.banco.prestamos.test;
import org.junit.Test;

import junit.framework.TestCase;


public class TestSimulacion extends TestCase {
	
	@Test
	public void test() {
		
	}
	
}
