package edu.udc.is.test.banco.prestamos.test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
   TestPrestamos.class,
   TestSimulacion.class
})

public class TestSuiteBanco {
	
}  	